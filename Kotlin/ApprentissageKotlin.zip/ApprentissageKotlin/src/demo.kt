import NePasToucher.readDouble
import NePasToucher.readInt
import NePasToucher.readString

fun main(args: Array<String>) {
    var ageUtilisateur: Int

    println("Entrez votre prénom :")
    val prenom = readString()

    println("Entrez votre taille (en mètres) :")
    val taille = readDouble()

    do {
        println("Entrez votre age : ")
        ageUtilisateur = readInt()

        println("Bonjour ${prenom}, vous mesurez ${taille}m et vous avez " + ageUtilisateur + " an(s)")
        if (ageUtilisateur >= 18) {
            println("Vous êtes majeur")
        } else if (ageUtilisateur > 12) {
            println("Vous êtes un ado")
        } else if (ageUtilisateur >= 0) {
            println("Vous êtes un enfant")
        } else {
            println("Vous êtes un boulet")
        }
    } while (ageUtilisateur < 0)
}

