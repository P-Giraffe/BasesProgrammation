﻿class MainClass
{
	public static void Main (string[] args)
	{
		Application app = new Application ();
		app.fonctionPrincipale ();
	}
}

